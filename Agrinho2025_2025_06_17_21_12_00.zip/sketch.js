let trator;
let produtos = [];
let obstaculos = [];
let cidade;
let pontos = 0;
let tempoInicial = 30;
let tempoRestante;
let gameOver = false;

function setup() {
  createCanvas(800, 500);
  trator = new Trator(50, height / 2);
  cidade = new Cidade(width - 80, height / 2);
  for (let i = 0; i < 5; i++) {
    produtos.push(new Produto(random(100, 600), random(50, height - 50)));
  }
  for (let i = 0; i < 3; i++) {
    obstaculos.push(new Obstaculo(random(200, 700), random(50, height - 50)));
  }
  tempoRestante = tempoInicial;
  setInterval(() => {
    if (!gameOver && tempoRestante > 0) tempoRestante--;
  }, 1000);
}

function draw() {
  background(180, 200, 255);

  // Desenhar campo e cidade
  fill(255, 160, 20);
  rect(0, 0, width / 2, height);
  cidade.display();

  // Mostrar trator
  trator.display();
  trator.move();

  // Mostrar e verificar produtos
  for (let i = produtos.length - 1; i >= 0; i--) {
    produtos[i].display();
    if (trator.coletou(produtos[i])) {
      produtos.splice(i, 1);
      pontos++;
    }
  }

  // Mostrar obstáculos
  for (let o of obstaculos) {
    o.display();
    if (trator.bateu(o)) {
      gameOver = true;
    }
  }

  // HUD
  fill(0);
  textSize(16);
  text(`Produtos coletados: ${pontos}`, 80, 20);
  text(`Tempo: ${tempoRestante}s`, 45, 40);

  // Verifica vitória
  if (pontos >= 5 && trator.x > width - 120) {
    fill(0, 200, 0);
    textSize(32);
    textAlign(CENTER);
    text("Parabéns! Entrega feita na cidade! 🎉", width / 2, height / 2);
    noLoop();
  }

  // Game Over
  if (tempoRestante <= 0 || gameOver) {
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER);
    text("Game Over! Pressione R para reiniciar", width / 2, height / 2);
    noLoop();
  }
}

function keyPressed() {
  if (key === 'R' || key === 'r') {
    reiniciarJogo();
  }
}

function reiniciarJogo() {
  pontos = 0;
  tempoRestante = tempoInicial;
  gameOver = false;
  trator = new Trator(50, height / 2);
  produtos = [];
  obstaculos = [];
  for (let i = 0; i < 5; i++) {
    produtos.push(new Produto(random(100, 600), random(50, height - 50)));
  }
  for (let i = 0; i < 3; i++) {
    obstaculos.push(new Obstaculo(random(200, 700), random(50, height - 50)));
  }
  loop();
}

// Classes

class Trator {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 30;
    this.velocidade = 2;
  }

  display() {
    fill(255, 0, 0);
    rect(this.x, this.y, this.tamanho, this.tamanho);
  }

  move() {
    if (keyIsDown(UP_ARROW)) this.y -= this.velocidade;
    if (keyIsDown(DOWN_ARROW)) this.y += this.velocidade;
    if (keyIsDown(LEFT_ARROW)) this.x -= this.velocidade;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.velocidade;

    this.x = constrain(this.x, 0, width - this.tamanho);
    this.y = constrain(this.y, 0, height - this.tamanho);
  }

  coletou(produto) {
    return dist(this.x, this.y, produto.x, produto.y) < 25;
  }

  bateu(obstaculo) {
    return dist(this.x, this.y, obstaculo.x, obstaculo.y) < 25;
  }
}

class Produto {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  display() {
    fill(255, 255, 0);
    ellipse(this.x, this.y, 23, 23);
  }
}

class Obstaculo {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  display() {
    fill(100);
    rect(this.x, this.y, 20, 20);
  }
}

class Cidade {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  display() {
    fill(80, 80, 200);
    rect(this.x, this.y - 50, 60, 150);
    fill(255);
    textAlign(CENTER);
    text("CIDADE", this.x + 30, this.y + 60);
  }
}
